<?php
/*
 * Plugin Name: Quick Notes 
 * Description: Quick Notes for users
 * 
 * Author URI:  https://www.linkedin.com/in/nataliia-bahdasarova-9618981b0/
 * Author:      Nataliia Bahdasarova 
 * 
 * Version:     1.0
 */
define( 'QuickNotes__DIR', plugin_dir_path( __FILE__ ) );
define( 'QuickNotes_URL', plugin_dir_url( __FILE__ ) );
//creating, deleting a table. adding and outputting data
require_once(QuickNotes__DIR . 'includes/class.quick-table.php'); 
//shortcode activation, shortcode data output
require_once(QuickNotes__DIR . 'includes/class.quick-shortcode.php'); 
//connecting styles and scripts
require_once(QuickNotes__DIR . 'includes/quick-assets.php'); 
//creating, deleting a table
$QuickNotesTable=new QuickNotesTable(); 
register_activation_hook(__FILE__, array($QuickNotesTable, 'plugin_activation'));
register_deactivation_hook(__FILE__, array($QuickNotesTable, 'plugin_deactivation'));
//connecting styles and scripts
add_action('wp_enqueue_scripts', 'quick_notes_assets');
//activate the shortcode
function run_QuickNotesShortcode() {
    new QuickNotesShortcode();
}
add_action('plugins_loaded', 'run_QuickNotesShortcode'); 
//getting data from a form using ajax
function save_new_notes() { 
    if ( isset($_REQUEST) ) {
        if ($_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest'){ 
            $title = (isset($_REQUEST['notes_title'])) ?  $_REQUEST['notes_title']  : '';
            $content = (isset($_REQUEST['notes_content'])) ?  $_REQUEST['notes_content']  : '';
            $user_id = (isset($_REQUEST['user_id'])) ?  (int)$_REQUEST['user_id']  : 0;
            if ($user_id > 0 && $title != '' && $content != '') { 
                $QuickNotesTable = new QuickNotesTable();
                $QuickNotesTable->insert_note($user_id, $title, $content);
                print $QuickNotesTable->get_notes($user_id, 1);
            }
        }
    }
    wp_die();  
}
add_action('wp_ajax_save_new_notes', 'save_new_notes');
add_action('wp_ajax_nopriv_save_new_notes', 'save_new_notes');