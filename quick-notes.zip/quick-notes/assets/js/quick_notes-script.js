jQuery(document).ready(function ($) {

    $('.form_add_notes').submit(function () {
        return false
    })
    $('.submit_add_notes').on('click', function () {
        var err = 0
        $('input, textarea').removeClass('error');

        $('.form-control').each(function () {
            if ($(this).val().trim() === '') {
                $(this).addClass('error');
                err++;
            } else {
                $(this).removeClass('error');
            }
        });
        if (err == 0) {
            $.ajax({
                type: 'POST',
                url: quick_notes_ajax_form.ajax_url,
                data: $('.form_add_notes').serialize(),
                success: function (data) {
                    $('.form_add_notes')[0].reset();
                    $('.show_all_notes').html(data);
                },
            })
        }
    });
})