
<?php
function quick_notes_assets() { 
    wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_style('quick_notes-style', QuickNotes_URL. 'assets/css/quick_notes-style.css');

    wp_enqueue_script('jquery');
    wp_enqueue_script('quick_notes-script', QuickNotes_URL . 'assets/js/quick_notes-script.js', array('jquery'), null, true);  
    wp_localize_script('quick_notes-script', 'quick_notes_ajax_form', array('ajax_url' => admin_url('admin-ajax.php')));
}