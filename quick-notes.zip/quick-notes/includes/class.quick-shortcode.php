<?php

class QuickNotesShortcode  { 
    public function __construct() { 
        add_shortcode('quick_notes',array($this,'quick_notes_function'));
    }
    //shortcode data output
    public function quick_notes_function($atts) { 
        $user_id = get_current_user_id();
        if (isset($atts['user_id'])) {
            $user_id=$atts['user_id'];
        }
        $QuickNotesTable = new QuickNotesTable();
        $page_id=1;
        if (isset($_GET['pages']))$page_id=$_GET['pages'];
        $content='';
        $content.= '<div class="container quick_notes">';
        $content.= '<div class="show_all_notes">';
        $content.= $QuickNotesTable->get_notes($user_id, $page_id);
        $content.= '</div>'; 
        $content.= '<form class="form_add_notes"> 
  <div class="form-group"> 
    <input type="text" class="form-control" name="notes_title" required id="notes_title" placeholder="'.__('Title','quick_notes').'">
  </div>
  <div class="form-group"> 
    <textarea type="text" class="form-control" name="notes_content" required id="notes_content" placeholder="'.__('Content','quick_notes').'"></textarea>
  </div> 
  <button type="submit" class="submit_add_notes btn">'.__('Add note','quick_notes').'</button>
  <input type="hidden" name="action" value="save_new_notes">
  <input type="hidden" name="user_id" value="'.$user_id.'">
</form>'; 
        $content.= '</div>';

        return $content;
    }  

}
add_shortcode('my_shortcode', 'my_shortcode_function'); 