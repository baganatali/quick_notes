<?php

class QuickNotesTable {
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'users_notes'; 
    }
    //creating a table
    public function plugin_activation() {
        global $wpdb;  
        if($wpdb->get_var( "show tables like '$this->table_name'" ) != $this->table_name ) 
        {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $this->table_name (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                title varchar(255) NOT NULL,   
                content text NOT NULL,   
                date datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset_collate;"; 
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);  
        }
    }
    //deleting a table
    public function plugin_deactivation() {
        global $wpdb;
        $sql = "DROP TABLE IF EXISTS $this->table_name;";
        $wpdb->query($sql); 
    }
    //outputting data
    public function get_notes($user_id,$page_id) {
        global $wpdb, $post;
        $content='';  
        $notes_per_page=3;
        $results = $wpdb->get_results( 
            $wpdb->prepare(
                "SELECT * FROM $this->table_name WHERE user_id = %d ORDER BY `date` DESC LIMIT %d, %d ",
                $user_id,
                $page_id,
                $notes_per_page 
            ) 
        );
        if (!empty($results)) {
            $total_notes = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}  WHERE user_id = '".$user_id."' ");
            $total_pages = ceil($total_notes / $notes_per_page);

            foreach ($results as $row) {
                $content .= '<div class="user_notes_item"><div class="row">
                <div class="col-md-9"><h6>'.$row->title.'</h6></div>
                <div class="col-md-3 small">'.$row->date.'</div>
                </div>
                '.$row->content.'
                </div>';
            }
            if ($total_pages>1) {
                $content .= '<ul class="user_notes_pages">';
                for ($i=1;$i<=$total_pages;$i++) {
                    $link='?pages='.$i;
                    if ($i==1) $link=get_permalink($post->ID);
                    if ($page_id==$i) $content .= '<li><span>'.$i.'</span></li>';
                    else $content .= '<li><a href="'.$link.'">'.$i.'</a></li>';
                }
                $content .= '</ul>';
            } 
        }
        return $content;
    }
    //adding  data
    public function insert_note($user_id, $title, $note) {
        global $wpdb;
        $wpdb->insert(
            $this->table_name,
            array(
                'user_id' => $user_id,
                'title' => $title,
                'content' => $note,
                'date' => current_time('mysql')
            )
        );
    }
}